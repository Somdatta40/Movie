package com.cg.mts.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.mts.entity.Transaction;

public class TransactionTest {
	public static Transaction tr;
	@BeforeAll
	public static void setUp() {
		System.out.println("This method id annoted with @before all to execute as first in Theatre Test");
		tr=new Transaction("Online","Confirmed",265.89, null, null);
	}
	@BeforeEach
	public void setUpForTest() {
		System.out.println("This method id annoted with ");
	
	}
	@Test
	public void testAdmin() {
		Transaction tr=new Transaction("Online","Confirmed",265.89, null, null);
		assertNotNull(tr);
		Transaction trOne=null;
		assertNull(trOne);
	}
	@Test
	public void testGetters() {
		assertEquals("Online",tr.getTmode());
		assertEquals("Confirmed",tr.getTstatus());
		assertEquals(265.89, tr.getTamount());
		
	}

	
	@AfterEach
	public void stopThis() {
		System.out.println("this method is annoted with @AfterEach"
				+ "to execute after each test case");
	}
	
	@AfterAll
	public static void stopAll() {
		System.out.println("this method is annoted with @AfterAll"
				+ " to execute as last method in the test class TransactionTest");
		tr = null;//now after assigning tr object to null it is eligible for removing from the memory
	}
	
}
