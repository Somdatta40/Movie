package com.cg.mts.entity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.mts.entity.Ticket;

public class TicketTest {
	public static Ticket ti;
	@BeforeAll
	public static void setUp() {
		System.out.println("This method id annoted with @before all to execute as first in Ticket Test");
		ti=new Ticket(true,"Inox");
	}
	@BeforeEach
	public void setUpForTest() {
		System.out.println("This method id annoted with ");
	
	}
	@Test
	public void testAdmin() {
		Ticket ti=new Ticket(true,"Inox");
		assertNotNull(ti);
		Ticket tiOne=null;
		assertNull(tiOne);
	}
	@Test
	public void testGetters() {
		assertEquals("Inox",ti.getScreenName());
		assertEquals(true,ti.isTicketStatus());
		
	}

	
	@AfterEach
	public void stopThis() {
		System.out.println("this method is annoted with @AfterEach"
				+ "to execute after each test case");
	}
	
	@AfterAll
	public static void stopAll() {
		System.out.println("this method is annoted with @AfterAll"
				+ " to execute as last method in the test class TicketTest");
		ti = null;//now after assigning ti object to null it is eligible for removing from the memory
	}
	
}
